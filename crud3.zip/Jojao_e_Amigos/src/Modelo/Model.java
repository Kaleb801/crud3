package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Persistencia.DAOHeranca;
import Util.Retorno;
public abstract class Model<TypePK> {
	@SuppressWarnings("unchecked")
	
	public Retorno<List<String>> camposObrigatoriosPreenchidos(){
		Retorno<List<String>> ret = new Retorno<List<String>>(true,"Campos Obrig�torios Preenchidos!!!");
		List<String> campos = new ArrayList<>();
			
		List<String> lista = this.getCamposObrigatorios();
		for(String campoNome : lista) {
			Object campoValor = this.getCamposValor(campoNome);
				if(  campoValor==null ||
						(campoValor instanceof String && ( ((String)campoValor).isEmpty())   ) 	
					  ) {
							campos.add("Campo "+campoNome + " n�o foi preenchido!!!");
					}
			}
			if(!campos.isEmpty()) {
				ret.setSucesso(false);
				ret.setDado(campos);
				ret.setMensagem(campos.toString());
			}
			return ret;
		}
	
		public abstract Object getCamposValor(String campoNome);
		public abstract List<String> getCamposObrigatorios();
		public abstract void ResultSet(ResultSet rs);
		public abstract PreparedStatement preencherSQLPreparada(PreparedStatement pst) throws SQLException;
		
}

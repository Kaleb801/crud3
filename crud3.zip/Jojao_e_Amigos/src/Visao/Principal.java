package Visao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class Principal extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse
		      response) throws ServletException, IOException {

		      sendPageHeader(response);
		      sendPageFooter(response);
		    }
	 
	 
	 public void doPost(HttpServletRequest request, HttpServletResponse
				response)throws ServletException, IOException {
			
			sendPageHeader(response);
		    sendPageFooter(response);
		}
	 
	 
	 private void sendPageHeader(HttpServletResponse response)
		      throws ServletException, IOException {

	      response.setContentType("text/html");
	      PrintWriter out = response.getWriter();
	      out.println("<HTML>");
	      out.println("<HEAD>");
	      out.println("<TITLE>Pagina Principal</TITLE>");
	      out.println("</HEAD>");
	      out.println("<BODY>");
	      out.println("<CENTER>");
	      out.println("<FORM METHOD=POST>");
	      out.println("<TH><H2>Pagina Inicial</H2></TH>");
	      out.println("<TR>");
	      out.println("<TABLE border=\"2\">");
	      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='ListarPersonagem';\" value=\"Listar Personagens\" /></TD>"); 
	      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='NovoPersonagem';\" value=\"Novo Personagem\" /></TD>"); 
	      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='ListarStand';\" value=\"Listar Stands\" /></TD>"); 
	      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='NovoStand';\" value=\"Novo Stand\" /></TD>"); 
		  
	      
	      
	    }

   private void sendPageFooter(HttpServletResponse response)
   	      throws ServletException, IOException {

   	      PrintWriter out = response.getWriter();
   	      out.println("</CENTER>");
   	      out.println("</BODY>");
   	      out.println("</HTML>");
   	    }
}

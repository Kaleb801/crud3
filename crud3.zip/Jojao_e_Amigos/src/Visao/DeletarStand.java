package Visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Stand;
import Util.Retorno;



@SuppressWarnings("serial")
public class DeletarStand extends HttpServlet {
	private int idid;


  public void init() {
      try {
        Class.forName("org.postgresql.Driver");
        System.out.println("JDBC driver carregado.");
      }
      catch (ClassNotFoundException e) {
        System.out.println(e.toString());
      }
    }

  public void doGet(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    sendUpdateForm(request, response);
    sendPageFooter(response);
  }


  public void doPost(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    updateRecord(request, response);
    sendPageFooter(response);
  }


  private void sendPageHeader(HttpServletResponse response)
    throws ServletException, IOException {

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    
    out.println("<HTML>");
    out.println("<HEAD>");
    out.println("<TITLE>Excluir Stand</TITLE>");
    out.println("</HEAD>");
    out.println("<BODY>");
    out.println("<CENTER>");
  }

  private void sendPageFooter(HttpServletResponse response)
    throws ServletException, IOException {

    PrintWriter out = response.getWriter();
    out.println("</CENTER>");
    out.println("</BODY>");
    out.println("</HTML>");
  }


  private void sendUpdateForm(HttpServletRequest request,
    HttpServletResponse response) throws IOException {

	String id = request.getParameter("id");
    int idAtualizar = Integer.parseInt(id);
    
    Control ctrl = new Control();
    Retorno<List<Stand>> stn = ctrl.listarTabelAtualizar(idAtualizar,new Stand());
    List<Stand> listaAtualizar = stn.getDado();
    
    Stand stand1 = (Stand)listaAtualizar.get(0);
    String nome = stand1.getNome();
    String poder = stand1.getPoder();
    
    PrintWriter out = response.getWriter();
    out.println("<BR><H2>Voc� realmente deseja excluir?</H2>");
    out.println("<BR>");
  
	    out.println("<BR><FORM METHOD=POST>");
	    out.println("<TABLE border=\"1\">");
        out.println("<TR>");
        out.println("<TD>Nome</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=nome value =\""+nome+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Poder</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=poder value=\""+poder+"\">");

        out.println("</TD>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD><INPUT readonly=\"readonly\" TYPE=SUBMIT value=\"Excluir\"></TD>");
        out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='ListarStand';\" value=\"Voltar\" /></TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        out.println("</FORM>");  
   
  }

  void updateRecord(HttpServletRequest request, HttpServletResponse
    response) throws IOException {
    String id = request.getParameter("id");
    String nome = request.getParameter("nome");
    String poder = request.getParameter("poder");
    PrintWriter out = response.getWriter();
    
    idid = Integer.parseInt(id);
    System.out.println(idid);
    
    Control crtl = new Control();
    crtl.excluirTab(idid,new Stand());
    
    out.println("<H2>Exclus�o Realizada!</H2>");
	out.println("<BR>");
    out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
  }
}

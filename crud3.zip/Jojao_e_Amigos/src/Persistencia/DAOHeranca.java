package Persistencia;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Modelo.Model;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;
import Anotacao.Campo;
import Anotacao.Tabela;

public class DAOHeranca {
	public DAOHeranca() {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public <T extends Model<?>> String getCamposNomeSelect(T tab) {
		String campos = new String();
		Class<?> cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		for (Field attr : atributos) {
			campos = campos.concat(attr.getName() + ",");
		}
		campos = campos.substring(0, campos.length() - 1);
		return campos;
	}
	
	public <T extends Model<?>> String getCamposNomeInsert(T tab) {
		String campos = new String();
		Class<?> cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
			for (int i = 1; i < atributos.length; i++) {
				campos = campos.concat(atributos[i].getName() + ",");
			}
		campos = campos.substring(0, campos.length() - 1);
		return campos;
	}
	
	public <T extends Model<?>> String getCamposNomeUpdate(T tab) {
		String campos = new String();
		Class cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		for (int i = 1; i < atributos.length; i++) {
			try {
				campos = campos.concat(atributos[i].getName()+"="+"'"+tab.getCamposValor(atributos[i].getName())) +"'"+",";
			} catch (SecurityException e) {
				e.printStackTrace();
			}
		}
		campos = campos.substring(0, campos.length() - 1);
		return campos;
	}
	
	public <T extends Model<?>> String getCamposInterrogacao(T tab) {
		String campos = new String();
		Class<?> cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		for (Field attr : atributos) {
			campos = campos.concat("?" + ",");
		}
		campos = campos.substring(0, campos.length() - 3);
		return campos;
	}

	public <T extends Model> Retorno<List<T>> listar(T tab) {
		Retorno<List<T>> retornoLista = new Retorno<List<T>>(true, "OK");
		String sql = "select " + getCamposNomeSelect(tab) + " from " + getTabName(tab);
		Retorno<PreparedStatement> retSQL = obterSQLPreparada(sql);
		if (retSQL.isSucesso() == false) {
			return new Retorno<List<T>>(retSQL);
		}
		Retorno<ResultSet> retResultado = executarSQLPreparadaConsulta(retSQL.getDado());
		if (retResultado.isSucesso() == false) {
			return new Retorno<List<T>>(retResultado);
		}
		ResultSet rs = retResultado.getDado();

		List<T> lista = new ArrayList<>();
		try {
			while (rs.next()) {
				Model newClass = tab.getClass().newInstance();
				newClass.ResultSet(rs);
				lista.add((T) newClass);
			}
		} catch (SQLException e) {
			retornoLista.setSucesso(false);
			retornoLista.setMensagem(e.getMessage());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		retornoLista.setDado(lista);
		return retornoLista;

	}

	private Retorno<PreparedStatement> obterSQLPreparada(String sql) {

		Retorno<PreparedStatement> ret = new Retorno<>(true, "OK");

		PreparedStatement pst = null;

		try {

			pst = Conexao.obterConexao().obterSQLPreparada(sql);
			ret.setDado(pst);

		} catch (SQLException e) {

			ret.setSucesso(false);

			ret.setMensagem("Erro de Conex�o com Banco: " + e.getMessage());

		}
		return ret;
	}

	public <T extends Model> Retorno<?> novoTabel(T tab) {
		// TODO Auto-generated method stub
		Retorno<?> retValidos = tab.camposObrigatoriosPreenchidos();

		if (retValidos.isSucesso() == false) {
			return retValidos;
		}

		String sql = "insert into "+getTabName(tab)+"("+getCamposNomeInsert(tab)+") "
				+ "values("+getCamposInterrogacao(tab)+")";
		Retorno<PreparedStatement> retSQL = obterSQLPreparada(sql);
		if (retSQL.isSucesso() == false) {
			return retSQL;
		}

		Retorno<?> ret2 = preencherSQLPreparada(retSQL.getDado(), tab);
		if (ret2.isSucesso() == false) {
			return ret2;
		}

		return executarSQLPreparadaAlteracao(retSQL.getDado());
	}

	private <T extends Model> Retorno<?> preencherSQLPreparada(PreparedStatement pst, T tab) {
		Retorno<?> ret = new Retorno<>(true, "OK");
		try {
			pst=tab.preencherSQLPreparada(pst);
		} catch (SQLException e) {
			ret.setSucesso(false);
			ret.setMensagem("Erro desconhecido 2: " + e.getMessage());
		}
		return ret;
	}

	private Retorno<Integer> executarSQLPreparadaAlteracao(PreparedStatement pst) {
		Retorno<Integer> ret = new Retorno<>(true, "Altera��o Executada com Sucesso");
		try {
			int linhasAlteracao = pst.executeUpdate();
			pst.close();
			ret.setDado(linhasAlteracao);
		} catch (SQLException e) {
			ret = tratarErroSQLPreparadaAlteracao(e);
		}
		return ret;
	}

	private Retorno<Integer> tratarErroSQLPreparadaAlteracao(SQLException e) {
		e.printStackTrace();
		Retorno<Integer> ret = new Retorno<>(false, "Erro desconhecido ao executar alteracao: " + e.getMessage());
		ret.setDado(0);
		if (e.getMessage().contains("Personagem_Nome_Unico")) {
			ret.setMensagem("Problemas com a edi��o/exclus�o");
		}
		return ret;
	}

	public <T extends Model> Retorno<?> editarTabel(T tab) {

		Class cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		
		Retorno<?> retValidos = tab.camposObrigatoriosPreenchidos();
		if (retValidos.isSucesso() == false) {
			return retValidos;
		}
		String sql = new String();
		try {
			sql = "UPDATE "+getTabName(tab)+ " SET "+getCamposNomeUpdate(tab)+" WHERE "+atributos[0].getName()+"="+"'"+tab.getCamposValor(atributos[0].getName())+"'";
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Retorno<PreparedStatement> retSQL = obterSQLPreparada(sql);
		if (retSQL.isSucesso() == false) {
			return retSQL;
		}

		return executarSQLPreparadaAlteracao(retSQL.getDado());

	}

	public <T extends Model> Retorno<List<T>> listarTabelAtualizar(int id, T tab) {
		
		Class<?> cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		
		Retorno<List<T>> retornoLista = new Retorno<List<T>>(true, "OK");
		String sql = "select " + getCamposNomeSelect(tab) + " from " + getTabName(tab)+ " WHERE "+atributos[0].getName()+"="+id;
		Retorno<PreparedStatement> retSQL = obterSQLPreparada(sql);
		if (retSQL.isSucesso() == false) {
			return new Retorno<List<T>>(retSQL);
		}

		Retorno<ResultSet> retResultado = executarSQLPreparadaConsulta(retSQL.getDado());
		if (retResultado.isSucesso() == false) {
			return new Retorno<List<T>>(retResultado);
		}
		ResultSet rs = retResultado.getDado();
		List<T> lista = new ArrayList<>();
		try {
			while (rs.next()) {
				Model newClass = tab.getClass().newInstance();
				newClass.ResultSet(rs);
				lista.add((T) newClass);
			}
		} catch (SQLException e) {
			retornoLista.setSucesso(false);
			retornoLista.setMensagem(e.getMessage());
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		retornoLista.setDado(lista);
		return retornoLista;
	}

	public static String getTabName(Model tab) {

		Class<?> cls = tab.getClass();
		if (cls.isAnnotationPresent(Tabela.class)) {
			Tabela cmp = cls.getAnnotation(Tabela.class);
			return cmp.nome();
		} else {
			return cls.getSimpleName().toLowerCase();
		}
	}

	private Retorno<ResultSet> executarSQLPreparadaConsulta(PreparedStatement pst) {
		Retorno<ResultSet> ret = new Retorno<>(true, "Consulta Executada com Sucesso");
		try {
			ResultSet rs = pst.executeQuery();
			ret.setDado(rs);
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		}
		return ret;
	}

	public <T extends Model<?>> Retorno<?> excluirTab(int id, T tab) {

		Class<?> cls = tab.getClass();
		Field[] atributos = cls.getDeclaredFields();
		String sql = "DELETE from "+getTabName(tab)+" WHERE "+atributos[0].getName()+"="+id;

		Retorno<PreparedStatement> retSQL = obterSQLPreparada(sql);
		if (retSQL.isSucesso() == false) {
			return retSQL;
		}

		return executarSQLPreparadaAlteracao(retSQL.getDado());

	}
}

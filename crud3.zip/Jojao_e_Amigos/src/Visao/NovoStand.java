package Visao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Stand;


public class NovoStand extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse
		      response) throws ServletException, IOException {

		      sendPageHeader(response);
		      insertDados(request, response);
		      sendPageFooter(response);
		    }
	 
	 
	 public void doPost(HttpServletRequest request, HttpServletResponse
				response)throws ServletException, IOException {
			
			sendPageHeader(response);
			insertRecord(request, response);
		    sendPageFooter(response);
		}
	 
	 
	 private void sendPageHeader(HttpServletResponse response)
		      throws ServletException, IOException {

		      response.setContentType("text/html");
		      PrintWriter out = response.getWriter();
		      out.println("<HTML>");		      
		      out.println("<HEAD>");
		      out.println("<TITLE>Adicionar Stand</TITLE>");
		      out.println("</HEAD>");
		      out.println("<BODY>");
		      out.println("<CENTER>");
		    }
	 
	    private void sendPageFooter(HttpServletResponse response)
	    	      throws ServletException, IOException {

	    	      PrintWriter out = response.getWriter();
	    	      out.println("</CENTER>");
	    	      out.println("</BODY>");
	    	      out.println("</HTML>");
	    	    }
	
	void insertDados (HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		
	   PrintWriter out = response.getWriter();
	    out.println("<FORM METHOD=POST>");
	    out.println("<TH>Novo Stand</TH>");
	    out.println("<TABLE border=\"1\" bgcolor=\"#FFFFFF\">");
		out.println("<TR>");
		out.println("<TH>Nome</TH>");
		out.print("<TD><INPUT TYPE=TEXT Name=nome>");
		out.println("</TR>");
		out.println("<TR>");
      
		out.println("<TH>Poder</TH>");
      	out.print("<TD><INPUT TYPE=TEXT Name=poder>");
      	out.println("</TR>");
      	out.println("<TR>");
            
      	out.println("<TD><INPUT TYPE=SUBMIT value=\"Enviar\"></TD>");
      	out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
      	out.println("</TR>");
      	out.println("</TABLE>");
      	out.println("</FORM>");
      
	}
	
	void insertRecord(HttpServletRequest request, HttpServletResponse
			response) throws IOException{
			PrintWriter out = response.getWriter();
			out.println("<div align=\"left\"><FORM ACTION=index.html>");
			out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");

			
			String nome = request.getParameter("nome");
			String poder = request.getParameter("poder");
			
			out.println("<H2>Stand cadastrado com sucesso!</H2>");
			out.println("<BR>");
			
			Stand stand = new Stand(nome, poder);
			Control crtl = new Control();
			crtl.novoTabel(stand);
			
	    	out.println("<BR>");
		}
		
	}



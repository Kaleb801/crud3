package Visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;


public class DeletarPersonagem extends HttpServlet {
	private int idid;
	private Integer id_teste;


  public void init() {
      try {
        Class.forName("org.postgresql.Driver");
        System.out.println("JDBC driver carregado.");
      }
      catch (ClassNotFoundException e) {
        System.out.println(e.toString());
      }
    }

  public void doGet(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    sendUpdateForm(request, response);
    sendPageFooter(response);
  }


  public void doPost(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    try {
		updateRecord(request, response);
	} catch (IOException | ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sendPageFooter(response);
  }



  private void sendPageHeader(HttpServletResponse response)
    throws ServletException, IOException {
    response.setContentType("text/html");
	PrintWriter out = response.getWriter();
    out.println("<HTML>");
    out.println("<HEAD>");
    out.println("<TITLE>Deletar Stand</TITLE>");
    out.println("</HEAD>");
    out.println("<BODY>");
    out.println("<CENTER>");
  }


  private void sendPageFooter(HttpServletResponse response)
    throws ServletException, IOException {

    PrintWriter out = response.getWriter();
    out.println("</CENTER>");
    out.println("</BODY>");
    out.println("</HTML>");
  }


  private void sendUpdateForm(HttpServletRequest request,
    HttpServletResponse response) throws IOException {

    String id = request.getParameter("id");
    PrintWriter out = response.getWriter();
    out.println("<BR><H2> Deseja realmente confirmar a exclus�o?</H2>");
    out.println("<BR>");
  
    int idUpdate = Integer.parseInt(id);
    
    Control ctrl = new Control();
    Retorno<java.util.List<Personagem>> personagem1 = ctrl.listarTabelAtualizar(idUpdate,new Personagem());
    java.util.List<Personagem> listaAtualizar = personagem1.getDado();
    
    Personagem perso1 = (Personagem)listaAtualizar.get(0);
    String nome_personagem = perso1.getNome();
    Integer idade = perso1.getIdade();
    Date nascimento = perso1.getNascimento();
    String signo = perso1.getSigno();
    String genero = perso1.getGenero();
    String nacionalidade = perso1.getNacionalidade();
    String sangue = perso1.getSangue();
    
    out.println("<BR>");
  
	    out.println("<BR><FORM METHOD=POST>");
	    out.println("<TABLE border=\"1\">");
        out.println("<TR>");
        out.println("<TD>Nome</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=nome_personagem value=\""+nome_personagem+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Idade</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=idade value=\""+idade+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");

        out.println("<TD>Nascimento</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=nascimento value=\""+nascimento+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Signo </TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=signo value=\""+signo+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>G�nero</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=genero value=\""+genero+"\">");
        
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Nacionalidade</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=nacionalidade value=\""+nacionalidade+"\">");
        
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Sangue</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=sangue value=\""+sangue+"\">");
        
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Stand</TD>");
        out.print("<TD><INPUT readonly=\"readonly\" TYPE=TEXT Name=stand>");
	 	out.println("</TR>");
		out.println("<TR>");
				

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
       
        out.println("</TD>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD><INPUT TYPE=SUBMIT value=\"Excluir\" ></TD>");
        out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='ListarPersonagem';\" value=\"Voltar\" /></TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        out.println("</FORM>");   

  }

  void updateRecord(HttpServletRequest request, HttpServletResponse
    response) throws IOException, ParseException {
    String id = request.getParameter("id");
    String nome_personagem = request.getParameter("nome_personagem");
    Integer idade = Integer.parseInt(request.getParameter("idade"));
	String dataEmTexto = request.getParameter("nascimento");
    System.out.println("campo data" + dataEmTexto);
    Date nascimento = (Date) 	new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTexto);
    String signo = request.getParameter("signo");
    String genero = request.getParameter("genero");
    String nacionalidade = request.getParameter("nacionalidade");
    String sangue = request.getParameter("sangue");
    String stand = request.getParameter("stand");
    PrintWriter out = response.getWriter();
    
    idid = Integer.parseInt(id);
    try {
    	
        
        Control crtl = new Control();
        crtl.excluirTab(idid,new Personagem());
		
	} catch (RuntimeException e) {
		// TODO: handle exception
		System.out.println("Erro ao deletar personagem");
		e.printStackTrace();
	}
    out.println("<H2>Exclus�o realizada com sucesso!</H2>");
	out.println("<BR>");
    out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
  }    
}

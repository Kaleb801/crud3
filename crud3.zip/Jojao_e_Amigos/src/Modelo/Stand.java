package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Anotacao.Campo;

@Anotacao.Tabela(nome = "stand")
public class Stand extends Model {
	@Campo(colunaNome = "idstand", isPk = true, isObrigatorio = true)
	private Integer idstand;
	private String nome;
	private String poder;

	public Integer getIdStand() {
		return idstand;
	}

	public void setIdStand(Integer idstand) {
		this.idstand = idstand;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPoder() {
		return poder;
	}

	public void setPoder(String poder) {
		this.poder = poder;
	}

	public Stand(String nome, String poder) {
		super();
		this.nome = nome;
		this.poder = poder;
	}

	@Override
	public String toString() {
		return "stand [nome=" + nome + ", poder=" + poder + "]";
	}

	@Override
	public Object getCamposValor(String campoStand) {
		// TODO Auto-generated method stub
		if (campoStand.equalsIgnoreCase("idstand")) {
			return this.getIdStand();
		}
		if (campoStand.equalsIgnoreCase("nome")) {
			return this.getNome();
		}
		if (campoStand.equalsIgnoreCase("poder")) {
			return this.getPoder();
		}
		throw new RuntimeException("Campo" + campoStand + "n�o existe");
	}

	@Override
	public List<String> getCamposObrigatorios() {
		List<String> list = new ArrayList<>();
		list.add("nome");
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public void ResultSet(ResultSet rs) {
		try {
			setIdStand(rs.getInt("idstand"));
			setNome(rs.getString("nome"));
			setPoder(rs.getString("poder"));
		} catch (SQLException e) {
		}
	}

	public Stand(Integer idstand, String nome, String poder) {
		super();
		this.idstand = idstand;
		this.nome = nome;
		this.poder = poder;
	}

	public Stand(Integer id) {
		super();
		this.idstand = id;
	}

	public Stand() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public PreparedStatement preencherSQLPreparada(PreparedStatement pst) throws SQLException {
		pst.setString(1, getNome());
		pst.setString(2, getPoder());
		return pst;
	}

}

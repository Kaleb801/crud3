package Modelo;

import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Anotacao.Campo;

@Anotacao.Tabela(nome = "personagem")
public class Personagem extends Model {
	@Campo(colunaNome = "id", isPk = true, isObrigatorio = true)
	private Integer id;
	@Campo(colunaNome = "nome_personagem", isPk = true, isObrigatorio = true)
	private String nome_personagem;
	private Integer idade;
	private Date nascimento;
	private String signo;
	private String genero;
	private String nacionalidade;
	private String sangue;
	@Campo(colunaNome = "stand", isPk = true, isObrigatorio = true)
	private Stand stand;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome_Personagem() {
		return nome_personagem;
	}

	public void setNome_Personagem(String nome_personagem) {
		this.nome_personagem = nome_personagem;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	public Date getNascimento() {
		return nascimento;
	}

	public void setNascimento(Date nascimento) {
		this.nascimento = nascimento;
	}

	public String getSigno() {
		return signo;
	}

	public void setSigno(String signo) {
		this.signo = signo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public String getSangue() {
		return sangue;
	}

	public void setSangue(String sangue) {
		this.sangue = sangue;
	}

	public Stand getStand() {
		return stand;
	}

	public void setStand(Stand stand) {
		this.stand = stand;
	}

	public Personagem(Integer id, String nome_personagem, Integer idade, Date nascimento, String signo, String genero,
			String nacionalidade, String sangue, Stand stand) {
		super();
		this.id = id;
		this.nome_personagem = nome_personagem;
		this.idade = idade;
		this.nascimento = nascimento;
		this.signo = signo;
		this.genero = genero;
		this.nacionalidade = nacionalidade;
		this.sangue = sangue;
		this.stand = stand;
	}

	public Personagem(String nome_personagem, Integer idade, Date nascimento, String signo, String genero,
			String nacionalidade, String sangue, Stand stand) {
		super();
		this.nome_personagem = nome_personagem;
		this.idade = idade;
		this.nascimento = nascimento;
		this.signo = signo;
		this.genero = genero;
		this.nacionalidade = nacionalidade;
		this.sangue = sangue;
		this.stand = stand;
	}

	@Override
	public String toString() {
		return "nome_personagem=" + nome_personagem + ", idade=" + idade + ", nascimento=" + nascimento + ", signo="
				+ signo + ", genero=" + genero + ", nacionalidade=" + nacionalidade + ", stand=" + stand;
	}

	@Override
	public Object getCamposValor(String campoNome) {
		// TODO Auto-generated method stub
		if (campoNome.equalsIgnoreCase("nome_personagem")) {
			return this.getNome_Personagem();
		}
		if (campoNome.equalsIgnoreCase("id")) {
			return this.getId();
		}
		if (campoNome.equalsIgnoreCase("idade")) {
			return this.getIdade();
		}
		if (campoNome.equalsIgnoreCase("nascimento")) {
			return this.getNascimento();
		}
		if (campoNome.equalsIgnoreCase("signo")) {
			return this.getSigno();
		}
		if (campoNome.equalsIgnoreCase("genero")) {
			return this.getGenero();
		}
		if (campoNome.equalsIgnoreCase("nacionalidade")) {
			return this.getNacionalidade();
		}
		if (campoNome.equalsIgnoreCase("sangue")) {
			return this.getSangue();
		}
		if (campoNome.equalsIgnoreCase("stand")) {
			return this.getStand().getIdStand();
		}
		throw new RuntimeException("Campo" + campoNome + "n�o existe");
	}

	@Override
	public List<String> getCamposObrigatorios() {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<>();
		list.add("nome_personagem");
		list.add("stand");
		return list;
	}

	@Override
	public void ResultSet(ResultSet rs) {
		try {
			setId(rs.getInt("id"));
			setNome_Personagem(rs.getString("nome_personagem"));
			setIdade(rs.getInt("idade"));
			setNascimento(rs.getDate("nascimento"));
			setSigno(rs.getString("signo"));
			setGenero(rs.getString("genero"));
			setNacionalidade(rs.getString("nacionalidade"));
			setSangue(rs.getString("sangue"));
			int stand2 = rs.getInt("stand");
			Stand s = new Stand();
			s.setIdStand(stand2);
			setStand(s);
		} catch (SQLException e) {
		}
	}

	@Override
	public PreparedStatement preencherSQLPreparada(PreparedStatement pst) throws SQLException {
		pst.setString(1, getNome_Personagem());
		pst.setInt(2, getIdade());
		pst.setDate(3, new java.sql.Date(getNascimento().getTime()));
		pst.setString(4, getSigno());
		pst.setString(5, getGenero());
		pst.setString(6, getNacionalidade());
		pst.setString(7, getSangue());
		pst.setInt(8, getStand().getIdStand());
		return pst;
	}

	public Personagem(int id) {
		super();
		this.id = id;
	}

	public Personagem() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		// TODO Auto-generated method stub
		return null;
	}
}

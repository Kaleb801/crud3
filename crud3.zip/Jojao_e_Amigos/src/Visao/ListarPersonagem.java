package Visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;


public class ListarPersonagem extends HttpServlet {
	private String keyword = "";

	public void init() {
		// TODO Auto-generated method stub
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("JDBC driver carregado.");
		    }
		catch (ClassNotFoundException e) {
			System.out.println(e.toString());
		    }
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse
		response) throws
			ServletException, IOException {
				sendPageHeader(response);
				sendSearchResult(response);
				sendPageFooter(response);
			 }

			  /**Process the HTTP Post request*/

	public void doPost(HttpServletRequest request, HttpServletResponse
		response) throws
			ServletException, IOException {
				sendPageHeader(response);
				sendSearchResult(response);
				sendPageFooter(response);
			}
	
	private void sendPageHeader(HttpServletResponse response)
			throws ServletException, IOException {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("<HTML>");
			     out.println("<HEAD>");
				out.println("<TITLE>Personagens</TITLE>");
				out.println("</HEAD>");
				out.println("<BODY>");
				out.println("<CENTER>");
			}
	void sendSearchResult(HttpServletResponse response)
		    throws IOException {
		      PrintWriter out = response.getWriter();
			      try {
			    	  	out.println("<FORM METHOD=POST  >");
			    	  	out.println("<TH><H2>Personagens</H2></TH>");
					  	out.println("<TABLE border=\"1\">");
						out.print("Chave de Busca: <INPUT TYPE=TEXT Name=keyword");
						out.print(" VALUE=\"" + keyword + "\"");
						out.println(">");
						out.println("<INPUT TYPE=SUBMIT>");
						out.println("</TR>");
				    	out.println("<TR>");
				    	out.println("</FORM>");
				    	out.println("<BR>");
				    	out.println("<BR>");
						out.println("<TR>");
						out.println("<TH>Nome</TH>");
						out.println("<TH>Idade</TH>");
						out.println("<TH>Nascimento</TH>");
						out.println("<TH>Signo</TH>");
						out.println("<TH>Genero</TH>");
						out.println("<TH>Nacionalidade</TH>");
						out.println("<TH>Sangue</TH>");
						out.println("<TH>Stand</TH>");
						out.println("</TR>");
			        
					  
						Control crtl = new Control();
						Retorno<List<Personagem>> lista = crtl.listar(new Personagem());
				      	List<Personagem> list = lista.getDado();
				      	for(Personagem Personagem : list) {
				  
				        	Integer id = Personagem.getId();
				        	Integer stand = Personagem.getStand().getIdStand();
				        	
				        	out.println("<TR>");
				            out.println("<TH>" + Personagem.getNome_Personagem()  + "</TH>");
				            out.println("<TH>" + Personagem.getIdade()	+	"</TH>");
				            out.println("<TH>" + Personagem.getNascimento() 		+ 	"</TH>");
				            out.println("<TH>" + Personagem.getSigno()+"</TH>");
				            out.println("<TH>" + Personagem.getGenero()   	+	"</TH>");
				            out.println("<TH>" + Personagem.getNacionalidade()   	+	"</TH>");
				            out.println("<TH>" + Personagem.getSangue()   	+	"</TH>");
				            
				            Control ctrl = new Control();
				            Retorno<List<Stand>> stn1 = ctrl.listarTabelAtualizar(stand,new Stand());
				            List<Stand> listatualizar = stn1.getDado();
				            Stand s = (Stand)listatualizar.get(0);
				            String nomeStn = s.getNome();
				            out.println("<TH>" + nomeStn+	"</TH>");
				            
				            out.println("<TD><A HREF=DeletarPersonagem?id=" + id + ">Deletar</A></TD>");
				            out.println("<TD><A HREF=EditarPersonagem?id=" + id + ">Editar</A></TD>");
				            out.println("</TR>");
				            
				        }

			       }
			      catch (Exception e) {
			    	  e.printStackTrace();
			      }
			      out.println("</TABLE>");
			      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='NovoPersonagem';\" value=\"Novo Personagem\" /></TD>");
			      out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
			      
			  }

	private void sendPageFooter(HttpServletResponse response)
			throws ServletException, IOException {
			    PrintWriter out = response.getWriter();
			    	out.println("</CENTER>");
			    	out.println("</BODY>");
					out.println("</HTML>");	
			}


}

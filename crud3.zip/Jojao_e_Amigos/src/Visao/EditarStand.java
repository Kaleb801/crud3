package Visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Stand;
import Util.Retorno;


public class EditarStand extends HttpServlet {
	private int idid;

    /**Process the HTTP Get request*/
  public void init() {
      try {
        Class.forName("org.postgresql.Driver");
        System.out.println("JDBC driver carregado.");
      }
      catch (ClassNotFoundException e) {
        System.out.println(e.toString());
      }
    }

  public void doGet(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    sendUpdateForm(request, response);
    sendPageFooter(response);
  }

   /**Process the HTTP Post request*/

  public void doPost(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    updateRecord(request, response);
    sendPageFooter(response);
  }

   /**
   * Send the HTML page header, including the title
   * and the <BODY> tag
   */

  private void sendPageHeader(HttpServletResponse response)
    throws ServletException, IOException {

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    out.println("<HTML>");
    out.println("<HEAD>");
    out.println("<TITLE>Editar Stand</TITLE>");
    out.println("</HEAD>");
    out.println("<BODY>");
    out.println("<CENTER>");
  }

   /**
   * Send the HTML page footer, i.e. the </BODY>
   * and the </HTML>
   */

  private void sendPageFooter(HttpServletResponse response)
    throws ServletException, IOException {

    PrintWriter out = response.getWriter();
    out.println("</CENTER>");
    out.println("</BODY>");
    out.println("</HTML>");
  }


  private void sendUpdateForm(HttpServletRequest request,
    HttpServletResponse response) throws IOException {

    String id = request.getParameter("id");
    int idAtualizar = Integer.parseInt(id);
    
    Control ctrl = new Control();
    Retorno<List<Stand>> stn = ctrl.listarTabelAtualizar(idAtualizar,new Stand());
    List<Stand> listaAtualizar = stn.getDado();
    
    Stand stn1 = (Stand)listaAtualizar.get(0);
    String nome = stn1.getNome();
    String poder = stn1.getPoder();
    
    PrintWriter out = response.getWriter();
    out.println("<BR><H2>Atualizar Stand</H2>");
    out.println("<BR>");
  
	    out.println("<BR><FORM METHOD=POST>");
	    out.println("<TABLE border=\"1\" bgcolor=\"#FFFFFF\">");
        out.println("<TR>");
        out.println("<TD>Nome</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=nome value=\""+nome+"\">");

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
        out.println("<TD>Poder</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=poder value=\""+poder+"\">");

        out.println("</TD>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD><INPUT TYPE=SUBMIT value=\"Editar\"></TD>");
        out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='ListarStand';\" value=\"Voltar\" /></TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        out.println("</FORM>");  
   
  }

  void updateRecord(HttpServletRequest request, HttpServletResponse
    response) throws IOException {
    String id = request.getParameter("id");
    String nome = request.getParameter("nome");
    String poder = request.getParameter("poder");
    PrintWriter out = response.getWriter();
    
    
    try {
    	
    	Stand stand = new Stand(idid = Integer.parseInt(id), nome, poder);
        Control crtl = new Control();
        crtl.editarTabel(stand);
		
	} catch (RuntimeException e) {
		System.out.println("Erro ao alterar Stand");
		e.printStackTrace();
	}

    out.println("<H2>Altera��o realizada com sucesso!</H2>");
	out.println("<BR>");
    out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
  }
}

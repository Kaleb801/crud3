	package Visao;
	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.List;
	
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	
	import Controle.Control;
	import Modelo.Stand;
	import Util.Retorno;

	
	public class ListarStand extends HttpServlet {
		private String keyword = "";

		private static final long serialVersionUID = 1L;

		public void init() {
			// TODO Auto-generated method stub
			try {
				Class.forName("org.postgresql.Driver");
				System.out.println("JDBC driver carregado.");
			    }
			catch (ClassNotFoundException e) {
				System.out.println(e.toString());
			    }
		}
	

		public void doGet(HttpServletRequest request, HttpServletResponse
			response) throws
				ServletException, IOException {
					sendPageHeader(response);
					sendSearchResult(response);
					sendPageFooter(response);
				 }
	
				  /**Process the HTTP Post request*/
	
		public void doPost(HttpServletRequest request, HttpServletResponse
			response) throws
				ServletException, IOException {
					sendPageHeader(response);
					sendSearchResult(response);
					sendPageFooter(response);
				}
		
		private void sendPageHeader(HttpServletResponse response)
				throws ServletException, IOException {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("<HTML>");
				    out.println("<HEAD>");
					out.println("<TITLE>Stands</TITLE>");
					out.println("</HEAD>");
					out.println("<BODY>");
					out.println("<CENTER>");
				}
		void sendSearchResult(HttpServletResponse response)
				throws IOException {
			PrintWriter out = response.getWriter();
			try {
				out.println("<FORM METHOD=POST>");
			    out.println("<TH><H2>Stands</H2></TH>");
			    out.println("<TABLE border=\"1\" >");
				out.print("Chave de Busca: <INPUT TYPE=TEXT Name=keyword");
				out.print(" VALUE=\"" + keyword + "\"");
				out.println(">");
				out.println("<INPUT TYPE=SUBMIT>");
				out.println("</TR>");
		    	out.println("<TR>");
		    	out.println("</FORM>");
		    	out.println("<BR>");
		    	out.println("<BR>");
				out.println("<TR>");
				out.println("<TH>Nome</TH>");
				out.println("<TH>Poder</TH>");
				out.println("</TR>");
				        
				Control crtl = new Control();
				Retorno<List<Stand>> lista = crtl.listar(new Stand());
				List<Stand> list = lista.getDado();
				for(Stand Stand : list) {
				        	
			       	Integer id = Stand.getIdStand();
		        	out.println("<TR>");
		            out.println("<TH>" + Stand.getNome()    	+ 	"</TH>");
		            out.println("<TH>" + Stand.getPoder()	+	"</TH>");
		            
		            out.println("<TD><A HREF=DeletarStand?id=" + id + ">Excluir</A></TD>");
		            out.println("<TD><A HREF=EditarStand?id=" + id + ">Editar</A></TD>");
				    out.println("</TR>");
				            
				}
	       }
			catch (Exception e) {
				e.printStackTrace();
			}
			out.println("</TABLE>");
			out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='NovoStand';\" value=\"Novo Stand\" /></TD>");
			out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
			
		}
	
		private void sendPageFooter(HttpServletResponse response)
				throws ServletException, IOException {
			PrintWriter out = response.getWriter();
			out.println("</CENTER>");
	    	out.println("</BODY>");
			out.println("</HTML>");	
		}
	
	}

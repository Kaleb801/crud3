package Visao;

import java.awt.List;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;




public class EditarPersonagem extends HttpServlet {
	private int idid;
	private Object id_stands;
	private int idStn;
	private int idPer;

    /**Process the HTTP Get request*/
  public void init() {
      try {
        Class.forName("org.postgresql.Driver");
        System.out.println("JDBC driver carregado.");
      }
      catch (ClassNotFoundException e) {
        System.out.println(e.toString());
      }
    }

  public void doGet(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    sendUpdateForm(request, response);
    sendPageFooter(response);
  }

   /**Process the HTTP Post request*/

  public void doPost(HttpServletRequest request, HttpServletResponse
    response) throws ServletException, IOException {

    sendPageHeader(response);
    try {
		updateRecord(request, response);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sendPageFooter(response);
  }

   /**
   * Send the HTML page header, including the title
   * and the <BODY> tag
   */

  private void sendPageHeader(HttpServletResponse response)
    throws ServletException, IOException {

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    
    out.println("<HTML>");
    out.println("<HEAD>");
    out.println("<TITLE>Editar Personagem</TITLE>");
    out.println("</HEAD>");
    out.println("<BODY>");
    out.println("<CENTER>");
  }

   /**
   * Send the HTML page footer, i.e. the </BODY>
   * and the </HTML>
   */

  private void sendPageFooter(HttpServletResponse response)
    throws ServletException, IOException {

    PrintWriter out = response.getWriter();
    out.println("</CENTER>");
    out.println("</BODY>");
    out.println("</HTML>");
  }


  private void sendUpdateForm(HttpServletRequest request,
    HttpServletResponse response) throws IOException {

    String id = request.getParameter("id");
    int idUpdate = Integer.parseInt(id);
    
    Control ctrl = new Control();
    System.out.println("id personagem para editar="+idUpdate);
    Retorno<java.util.List<Personagem>> perso = ctrl.listarTabelAtualizar(idUpdate,new Personagem());
    java.util.List<Personagem> listaAtualizar = perso.getDado();
    System.out.println(listaAtualizar);
    Personagem perso1 = (Personagem)listaAtualizar.get(0);
    String nome_personagem = perso1.getNome_Personagem();
    Integer idade = perso1.getIdade();
    Date nascimento = perso1.getNascimento();
    String signo = perso1.getSigno();
    String genero = perso1.getGenero();
    String nacionalidade = perso1.getNacionalidade();
    String sangue = perso1.getSangue();
    
    PrintWriter out = response.getWriter();
    out.println("<BR><H2>Alterar Personagem</H2>");
    out.println("<BR>");
  
	    out.println("<BR><FORM METHOD=POST>");
	    out.println("<TABLE border=\"1\">");
        out.println("<TR>");
        out.println("<TD>Nome</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=nome_personagem value=\""+nome_personagem+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Idade</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=idade value=\""+idade+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Nascimento</TD>");
        out.print("<TD><INPUT TYPE=DATE Name=nascimento value=\""+nascimento+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Signo</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=signo value=\""+signo+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Genero</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=genero value=\""+genero+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Nacionalidade</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=nacionalidade value=\""+nacionalidade+"\">");
        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD>Sangue</TD>");
        out.print("<TD><INPUT TYPE=TEXT Name=sangue value=\""+sangue+"\">");
        out.println("</TR>");
        out.println("<TR>");
        
        Control ctrl1 = new Control();
        Retorno<java.util.List<Stand>> liststn = ctrl1.listar(new Stand());
        java.util.List<Stand> liststnd = new ArrayList<>();
        liststnd = liststn.getDado();
        
        if(liststnd.isEmpty()) {
			out.println("Nenhum Stand encontrado");
			}else {
				
				
				 out.println("<TH>Stand</TH> <TD><select name=\"stand\">\r\n" );
						 	for(Stand stn1 : liststnd ) {
						 		id_stands = stn1.getIdStand();
						 		System.out.println(id_stands);
						 		out.println("			<option value=\""+id_stands+"\">"+stn1.getNome()+"</option>\r\n" );
						 	}
						 		out.println("		</select> <br> <br> \r\n</"+"");
						 		out.println("</TR>");
						 		out.println("<TR>");
				
			}

        out.println("</BR>");
        out.println("</TR>");
        out.println("<TR>");
        
       
        out.println("</TD>");
        out.println("</TR>");
        out.println("<TR>");
        out.println("<TD><INPUT TYPE=SUBMIT value=\"Enviar\" ></TD>");
        out.println("</TR>");
        out.println("</TABLE>");
        out.println("<TD><A HREF=Principal>voltar</A></TD>");
        out.println("</FORM>");  
   
  }

  void updateRecord(HttpServletRequest request, HttpServletResponse
    response) throws IOException, ParseException {
    String id = request.getParameter("id");
    String nome_personagem = request.getParameter("nome_personagem");
    Integer idade = 			Integer.parseInt(request.getParameter("idade"));
    String dataEmTexto = request.getParameter("nascimento");
    Date nascimento = (Date) 	new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTexto);
	System.out.println("campo data" + nascimento);
    String signo = request.getParameter("signo");
    String genero = request.getParameter("genero");
    String nacionalidade = request.getParameter("nacionalidade");
    String sangue = request.getParameter("sangue");
    String stand = request.getParameter("stand");
    PrintWriter out = response.getWriter();
    
    Stand stn2 = new Stand(idStn = Integer.parseInt(stand));
    idid = Integer.parseInt(id);
    Personagem personagem = new Personagem(idPer = Integer.parseInt(id), nome_personagem, 
    		idade, nascimento, signo, genero, nacionalidade, sangue, stn2);

        Control crtl = new Control();
        crtl.editarTabel(personagem);

        out.println("<H2>Altera��o realizada com sucesso!</H2>");
    	out.println("<BR>");
        out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");
  }
}

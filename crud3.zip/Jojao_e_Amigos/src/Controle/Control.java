package Controle;

import java.util.List;

import Persistencia.DAOHeranca;
import Modelo.Model;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;

public class Control {
	DAOHeranca daoHeranca = new DAOHeranca();
	
	public <T extends Model> Retorno<List<T>> listar(T tab) {
		Retorno retorno = daoHeranca.listar(tab);
		return retorno;
	}

	public <T extends Model> Retorno novoTabel(T tab) {
		System.out.println("DAO vendo variavel  no controle"+ tab);
		Retorno retorno = daoHeranca.novoTabel(tab);
		// TODO Auto-generated method stub
		return retorno;
	}

	public <T extends Model> Retorno<List<Stand>> editarTabel(T tab) {
		Retorno retorno = daoHeranca.editarTabel(tab);
		return retorno;
		// TODO Auto-generated method stub
		
	}

	public <T extends Model> Retorno excluirTab(Integer idid, T tab) {
		Retorno retorno = daoHeranca.excluirTab(idid,tab);
		System.out.println(retorno);
		return retorno;
		// TODO Auto-generated method stub
		
	}

	public <T extends Model> Retorno<List<T>> listarTabelAtualizar(int idAtualizar,T tab) {
		// TODO Auto-generated method stub
		Retorno retorno = daoHeranca.listarTabelAtualizar(idAtualizar,tab);
		return retorno;
	}
}

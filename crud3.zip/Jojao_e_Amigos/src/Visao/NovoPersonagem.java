package Visao;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controle.Control;
import Modelo.Personagem;
import Modelo.Stand;
import Util.Retorno;




/**
 * Servlet implementation class NovoCelular
 */
@SuppressWarnings("serial")
public class NovoPersonagem extends HttpServlet {
	 private Object id_teste;


	public void doGet(HttpServletRequest request, HttpServletResponse
		      response) throws ServletException, IOException {

		      sendPageHeader(response);
		      insertDados(request, response);
		      sendPageFooter(response);
		    }
	 
	 
	 public void doPost(HttpServletRequest request, HttpServletResponse
				response)throws ServletException, IOException {
			
			sendPageHeader(response);
			try {
				insertRecord(request, response);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    sendPageFooter(response);
		}
	 
	 
	 private void sendPageHeader(HttpServletResponse response)
		      throws ServletException, IOException {

		      response.setContentType("text/html");
		      PrintWriter out = response.getWriter();
		      out.println("<HTML>");
		      out.println("<HEAD>");
		      out.println("<TITLE>Adicionar Personagem</TITLE>");
		      out.println("</HEAD>");
		      out.println("<BODY>");
		      out.println("<CENTER>");
		    }
	 
	    private void sendPageFooter(HttpServletResponse response)
	    	      throws ServletException, IOException {

	    	      PrintWriter out = response.getWriter();
	    	      out.println("</CENTER>");
	    	      out.println("</BODY>");
	    	      out.println("</HTML>");
	    	    }
	
	void insertDados (HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		
	    PrintWriter out = response.getWriter();
	    out.println("<FORM METHOD=POST>");
	    out.println("<TH><H2>Novo Personagem</H2></TH>");
	    out.println("<TABLE border=\"1\">");
		out.println("<TR>");
		out.println("<TH>Nome</TH>");
		out.print("<TD><INPUT TYPE=TEXT Name=nome_personagem>");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Idade</TH>");
       out.print("<TD><INPUT TYPE=NUMBER Name=idade>");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Nascimento</TH>");
       out.print("<TD><INPUT TYPE=DATE Name=nascimento> ");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Signo</TH>");
       out.print("<TD><INPUT TYPE=TEXT Name=signo>");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Genero</TH>");
       out.print("<TD><INPUT TYPE=TEXT Name=genero>");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Nacionalidade</TH>");
       out.print("<TD><INPUT TYPE=TEXT Name=nacionalidade>");
       out.println("</TR>");
       out.println("<TR>");
       
       out.println("<TH>Sangue</TH>");
       out.print("<TD><INPUT TYPE=TEXT Name=sangue>");
       out.println("</TR>");
       out.println("<TR>");
    
       Control crtl = new Control();
       Retorno<List<Stand>> listStn = crtl.listar(new Stand());
       List<Stand> listStns = new ArrayList<>();
       listStns = listStn.getDado();
		if(listStns.isEmpty()) {
			out.println("Nenhum Stand encontrado");
			}else {	
				 out.println("<TH>Stand</TH><TD><select name=\"stand\">\r\n" );
				 
						 		for(Stand stn : listStns ) {
						 		id_teste = stn.getIdStand();
						 		System.out.println("id do stand:"+ id_teste);
						 		out.println("			<option value=\""+id_teste+"\">"+stn.getNome()+"</option>\r\n" );
						 		
						 	}
						 	out.println("</select> <br> <br> \r\n</"+"");
			                out.println("</TR>");
			                out.println("<TR>");
				
			}
       
       out.println("<TD><INPUT TYPE=SUBMIT value=\"Enviar\" ></TD>");
       out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>"); 
       out.println("</TR>");
       out.println("</TABLE>");
       out.println("</FORM>");
       
	}
	
	void insertRecord(HttpServletRequest request, HttpServletResponse
			response) throws IOException, ParseException{
		String nome_personagem =	request.getParameter("nome_personagem");
		Integer idade = 			Integer.parseInt(request.getParameter("idade"));
		String dataEmTexto = request.getParameter("nascimento");
		System.out.println("campo data" + dataEmTexto);
		Date nascimento = (Date) 	new SimpleDateFormat("yyyy-MM-dd").parse(dataEmTexto);
		System.out.println("campo data" + nascimento);
		String signo = 				request.getParameter("signo");
		System.out.println("campo data" + signo);
		String genero = 			request.getParameter("genero");
		System.out.println("campo data" + genero);
		String nacionalidade = 		request.getParameter("nacionalidade");
		System.out.println("campo data" + nacionalidade);
		String sangue = 			request.getParameter("sangue");
		System.out.println("campo data" + sangue);
		String stand = 				request.getParameter("stand");
		PrintWriter out = response.getWriter();
		
		System.out.println("stand"+nome_personagem+" "+idade+" "+ nascimento+" "+ signo+" "+ genero+" "+nacionalidade+" "+sangue+" "+stand+"");
		Stand s2 = new Stand(Integer.parseInt(stand));
				
		Personagem personagem = new Personagem(nome_personagem, idade, nascimento, signo, genero, nacionalidade, sangue, s2);
		Control crtl = new Control();
		crtl.novoTabel(personagem);

		System.out.println("campos dentro da variavel "+personagem);
			out.println("<H2>Personagem cadastrado com sucesso!</H2>");
			System.out.println("id stand passou por s2"+ s2.getIdStand());

			out.println("<BR>");
			out.println("<TD><input type=\"button\" onclick=\"javascript: location.href='Principal';\" value=\"Voltar\" /></TD>");  

}
}

